#include "../include/server.h"

Server::Server(unsigned short int port) {
	this->port = port;
	FD_ZERO(&file_descs);
}

Server::Server() {
	port = 6000;
	FD_ZERO(&file_descs);
}

Server::~Server(){}

bool Server::create_socket() {

	struct sockaddr_in name;

	server_socket = socket(PF_INET, SOCK_STREAM, 0);

	if (socket < 0) {
		cout << "Error creating socket" << endl; 
		return false;
	}

	name.sin_family = AF_INET;
	name.sin_port = htons(port);
	name.sin_addr.s_addr = htonl(INADDR_ANY);

	if (bind (server_socket, (struct sockaddr *)&name, sizeof(name)) < 0) {
		cout << "Error binding socket" << endl;
		return false;
	}
	return true;
}

bool Server::start_server() {

	if (listen(server_socket, 1) < 0) {
		cout << "Error listening" << endl;
		return false;
	}
	return true;
}

int Server::get_fd() {
	return server_socket;
}

bool Server::wait() {

	FD_SET(server_socket, &file_descs);

	while (true) {
		ready_descs = file_descs;
		if (select(FD_SETSIZE, &ready_descs, NULL, NULL, NULL) < 0) {
			cout << "Select error" << endl;
			return false;
		}

		if(!service_sockets()) {
			return false;
		}
	}
	return true;
}

bool Server::service_sockets() {

	struct sockaddr_in client;
	socklen_t size;

	for (int i = 0; i < FD_SETSIZE; ++i) {
		if (FD_ISSET(i, &ready_descs)) {
			if (i == server_socket) {

				int new_connection;
				size = sizeof(client);
				new_connection = accept(server_socket, (struct sockaddr *) &client, &size);

				if(new_connection < 0) {
					cout << "Accept error" << endl;
					return false;
				}

				cout << "Server: connect from host: " << inet_ntoa(client.sin_addr)
				<< ", port: " << ntohs(client.sin_port) << endl; 

				FD_SET(new_connection, &file_descs); 
			}
			else {
				cout << "YOYOYOY" << endl;
			}
		}
	}

	return true;
}