#include <iostream>

#include "../include/server.h"

using namespace std;

int main() {

	Server server(7000);

	if (!server.create_socket()) {
		return -1;
	}
	
	if(!server.start_server()) {
		return -1;
	}

	if(!server.wait()) {
		return -1;
	}
	
	cout << "Server exited without errors" << endl;
	return 0;
	
}