#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>

using namespace std;

class Server
{
public:
	Server(unsigned short int port);
	Server();
	~Server();

	bool create_socket();
	bool start_server();
	bool wait();
	int get_fd();
	
private:
	int server_socket;
	unsigned short int port;
	fd_set file_descs;
	fd_set ready_descs;

	bool service_sockets();
};

#endif